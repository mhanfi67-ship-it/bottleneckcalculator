// PC Health Lab
// The calculator logic is kept in index.html in this version for compatibility.
// Shared page scripts can be added here as the project grows.
